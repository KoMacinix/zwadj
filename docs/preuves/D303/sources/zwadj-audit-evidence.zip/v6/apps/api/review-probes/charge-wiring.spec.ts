import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { BookingsService as BookingsV6 } from "../src/venues/bookings.service";
import { QuotesService as QuotesV6 } from "../src/venues/quotes.service";
import { BookingsService as BookingsV5 } from "../../../../zwadj-audit/apps/api/src/venues/bookings.service";
import { QuotesService as QuotesV5 } from "../../../../zwadj-audit/apps/api/src/venues/quotes.service";
import { resolveCharge, type CatalogueRow } from "../src/venues/booking-charge";
import type { BookingCreateInput, QuoteCreateInput } from "@zwadj/types";

// Diagnostic fixture: real application services and pricing; persistence stops
// at the write boundary. No database or real customer data is used.
const venueId = "0199aa00-0000-7000-8000-000000000001";
const serviceId = "0199aa00-0000-7000-8000-000000000002";
const slotId = "0199aa00-0000-7000-8000-000000000003";
const slot = { id: slotId, nameFr: "Soirée", nameAr: "سهرة", startMinutes: 1200,
  endMinutes: 1560, basePriceCents: 30_000_000, pricingRules: [] };
const venue = { id: venueId, bookingMode: "MULTI_SLOT", capacityMax: 400,
  depositRateBps: 3000, depositAmountCents: null, slotTemplates: [slot] };
const decoration: CatalogueRow = { id: serviceId, venueId, nameFr: "Décoration", nameAr: "زينة",
  pricingType: "FIXED", isActive: true,
  pricing: { fixedPriceCents: 5_000_000, perGuestPriceCents: null,
    perUnitPriceCents: null, minUnits: null, maxUnits: null }, tiers: [] };
const stopped = new Error("AUDIT_STOP_BEFORE_PERSISTENCE");

function setup() {
  const bookingWrite = vi.fn().mockRejectedValue(stopped);
  const quoteWrite = vi.fn().mockRejectedValue(stopped);
  const prisma = {
    venue: { findFirst: vi.fn().mockResolvedValue(venue), findUniqueOrThrow: vi.fn().mockResolvedValue(venue) },
    holiday: { findMany: vi.fn().mockResolvedValue([]) },
    service: { findMany: vi.fn().mockResolvedValue([decoration]) },
    user: { findUnique: vi.fn().mockResolvedValue({ id: "audit-client", email: "audit@example.invalid", locale: "fr" }) },
    booking: { create: bookingWrite }
  };
  const store = { salleAppartientAu: vi.fn().mockResolvedValue(true), creerTeteDeChaine: quoteWrite };
  const p = prisma as unknown as ConstructorParameters<typeof BookingsV6>[0];
  const q = store as unknown as ConstructorParameters<typeof QuotesV6>[0];
  const locks = {} as ConstructorParameters<typeof BookingsV6>[1];
  const events = { publish: vi.fn() } as unknown as ConstructorParameters<typeof BookingsV6>[2];
  return { prisma, bookingWrite, quoteWrite,
    bookingsV5: new BookingsV5(p, locks, events), bookingsV6: new BookingsV6(p, locks, events),
    quotesV5: new QuotesV5(q, p), quotesV6: new QuotesV6(q, p) };
}

function request(duplicate = false): BookingCreateInput {
  return { eventDate: "2027-08-15", slotTemplateId: slotId, guests: 100,
    paymentMethod: "ONLINE", contactFirstName: "Audit", contactLastName: "Test",
    contactPhone: "+213550000001", expectedTotalCents: duplicate ? 40_000_000 : 35_000_000,
    expectedDepositCents: duplicate ? 12_000_000 : 10_500_000,
    services: duplicate ? [{ serviceId }, { serviceId }] : [{ serviceId }] };
}
function quoteRequest(duplicate = false): QuoteCreateInput {
  const { eventDate, slotTemplateId, guests, services } = request(duplicate);
  return { eventDate, slotTemplateId, guests, services };
}

beforeEach(() => { vi.useFakeTimers(); vi.setSystemTime(new Date("2026-09-09T12:00:00Z")); });
afterEach(() => vi.useRealTimers());

describe("Version comparison at the real service write boundary", () => {
  it("v5: duplicate booking lines reach persistence with a doubled charge", async () => {
    const f = setup();
    await expect(f.bookingsV5.create("audit-client", "audit-salle", request(true))).rejects.toBe(stopped);
    expect(f.bookingWrite.mock.calls[0][0].data).toMatchObject({ totalCents: 40_000_000, depositCents: 12_000_000 });
    expect(f.bookingWrite.mock.calls[0][0].data.services.create).toHaveLength(2);
  });
  it("v5: duplicate quote lines reach persistence with a doubled charge", async () => {
    const f = setup();
    await expect(f.quotesV5.create("audit-pro", venueId, quoteRequest(true))).rejects.toBe(stopped);
    expect(f.quoteWrite.mock.calls[0][1]).toMatchObject({ totalCents: 40_000_000, depositCents: 12_000_000 });
    expect(f.quoteWrite.mock.calls[0][1].lines).toHaveLength(2);
  });
  it.each(["booking", "quote"] as const)("v6: %s refuses duplicate choices before writing", async (kind) => {
    const f = setup();
    const result = kind === "booking"
      ? f.bookingsV6.create("audit-client", "audit-salle", request(true))
      : f.quotesV6.create("audit-pro", venueId, quoteRequest(true));
    await expect(result).rejects.toMatchObject({ status: 409, response: { code: "SERVICE_DUPLICATE" } });
    expect(f.bookingWrite).not.toHaveBeenCalled(); expect(f.quoteWrite).not.toHaveBeenCalled();
  });
  it.each(["booking", "quote"] as const)("v6: %s refuses a catalogue row from another venue", async (kind) => {
    const f = setup();
    f.prisma.service.findMany.mockResolvedValue([{ ...decoration, venueId: "another-venue" }]);
    const result = kind === "booking"
      ? f.bookingsV6.create("audit-client", "audit-salle", request())
      : f.quotesV6.create("audit-pro", venueId, quoteRequest());
    await expect(result).rejects.toMatchObject({ status: 409, response: { code: "SERVICE_UNAVAILABLE" } });
    expect(f.bookingWrite).not.toHaveBeenCalled(); expect(f.quoteWrite).not.toHaveBeenCalled();
  });
  it.each(["booking", "quote"] as const)("v6: %s preserves correct totals and snapshots", async (kind) => {
    const f = setup();
    const result = kind === "booking"
      ? f.bookingsV6.create("audit-client", "audit-salle", request())
      : f.quotesV6.create("audit-pro", venueId, quoteRequest());
    await expect(result).rejects.toBe(stopped);
    const data = kind === "booking" ? f.bookingWrite.mock.calls[0][0].data : f.quoteWrite.mock.calls[0][1];
    expect(data).toMatchObject({ basePriceCents: 30_000_000, servicesTotalCents: 5_000_000,
      totalCents: 35_000_000, depositCents: 10_500_000 });
    const lines = kind === "booking" ? data.services.create : data.lines;
    expect(lines).toHaveLength(1); expect(lines[0]).toMatchObject({ serviceId, lineTotalCents: 5_000_000 });
  });
  it("v6: expected-price mismatch returns authoritative totals without writing", async () => {
    const f = setup();
    await expect(f.bookingsV6.create("audit-client", "audit-salle", {
      ...request(), expectedDepositCents: 1
    })).rejects.toMatchObject({ status: 409, response: { code: "BOOKING_PRICE_CHANGED",
      totalCents: 35_000_000, depositCents: 10_500_000 } });
    expect(f.bookingWrite).not.toHaveBeenCalled();
  });
});

it("diagnostic: unavailable-versus-invalid-line priority still depends on choice order", () => {
  const firstInvalid = { serviceId, tierId: "tier-for-a-fixed-service" };
  const unavailable = { serviceId: "missing-service" };
  const base = { venueId, basePriceCents: slot.basePriceCents, guests: 100,
    catalogue: [decoration], deposit: venue };
  expect(resolveCharge({ ...base, choices: [firstInvalid, unavailable] })).toEqual({ ok: false,
    failure: { code: "SERVICE_TIER_MISMATCH" } });
  expect(resolveCharge({ ...base, choices: [unavailable, firstInvalid] })).toEqual({ ok: false,
    failure: { code: "SERVICE_UNAVAILABLE" } });
});
