import base from './vitest.config';
export default {
  ...base,
  test: {
    ...base.test,
    include: ['audit-probes/**/*.spec.ts'],
    maxWorkers: 1
  }
};
