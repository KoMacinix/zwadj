import { afterEach, describe, expect, it, vi } from 'vitest';
import { BookingsService } from '../src/venues/bookings.service';
import { PrismaBookingLocks } from '../src/venues/booking-locks.prisma';
import { QuotesService } from '../src/venues/quotes.service';
import { PrismaQuoteStore } from '../src/venues/quote-store.prisma';
import { AuthService } from '../src/auth/auth.service';
import { ChargilyGateway } from '../src/payments/chargily.gateway';
import { buildBookingNotification } from '../src/venues/booking-notification-input';

const ID = '018f0000-0000-7000-8000-00000000dddd';
const VENUE = '018f0000-0000-7000-8000-00000000eeee';
const USER = '018f0000-0000-7000-8000-00000000aaaa';
const AT = new Date('2027-05-12T00:00:00Z');
const booking = () => ({
  id: ID, venueId: VENUE, clientId: USER, status: 'PENDING',
  paymentMethod: 'CASH', eventDate: AT, startsAt: AT,
  endsAt: new Date(AT.getTime() + 3_600_000), slotNameFr: 'Soiree', slotNameAr: 'Soiree',
  guests: 200, basePriceCents: 18_000_000, servicesTotalCents: 0,
  totalCents: 18_000_000, depositCents: 5_400_000, services: [],
  clientMessage: null, declineReason: null, cancellationReason: null,
  contactFirstName: 'Client', contactLastName: 'Test', contactPhone: '0550000000',
  contactEmail: null, expiresAt: null, paymentDueAt: null, createdAt: AT,
  venue: { slug: 'salle-test', nameFr: 'Salle', nameAr: 'Salle' }
});
const quote = () => ({
  id: ID, venueId: VENUE, clientId: null, status: 'DRAFT', version: 1,
  chainId: ID, parentQuoteId: null, eventDate: AT, slotTemplateId: null,
  guests: 200, basePriceCents: 18_000_000, servicesTotalCents: 0,
  totalCents: 18_000_000, depositCents: 5_400_000, lines: [],
  sentAt: null, sentVia: null, acceptedAt: null, createdAt: AT,
  booking: null as { id: string } | null
});

afterEach(() => vi.unstubAllGlobals());

describe('Audit reproductions — assertions describe observed defects, not desired behavior', () => {
  it('real lowercase Arabic locales are converted to French in booking notifications', () => {
    const result = buildBookingNotification(booking() as any, {
      id: VENUE, nameFr: 'Salle', nameAr: 'Salle',
      owner: { phone: '0550000000', notifyByEmail: true, notifyBySms: false,
        user: { id: USER, email: 'pro@example.com', locale: 'ar' } }
    }, { id: USER, email: 'client@example.com', locale: 'ar' }, null);
    expect(result.pro.locale).toBe('fr');
    expect(result.client?.locale).toBe('fr');
  });

  it('accept can overwrite a decline committed after its status read', async () => {
    const live = booking();
    const prisma: any = {
      $queryRaw: vi.fn(async () => []),
      booking: {
        findUniqueOrThrow: vi.fn(async () => ({ status: live.status })),
        update: vi.fn(async ({ data }) => {
          expect(live.status).toBe('DECLINED');
          Object.assign(live, data);
          return { ...live };
        })
      },
      availabilityBlock: { findFirst: vi.fn(async () => {
        live.status = 'DECLINED'; // transition() locks the booking, not the venue
        return null;
      }) },
      $transaction: async (cb: any) => cb(prisma)
    };
    const result = await new PrismaBookingLocks(prisma).acceptUnderVenueLock({
      bookingId: ID, venueId: VENUE, startsAt: AT, endsAt: live.endsAt,
      allowedFrom: ['PENDING'], to: 'ACCEPTED', acceptedAt: AT, paymentDueAt: null
    });
    expect(result.outcome).toBe('ACCEPTED');
    expect(live.status).toBe('ACCEPTED');
    expect(prisma.booking.update.mock.calls[0][0].where).toEqual({ id: ID });
  });

  it('a concurrent acceptance bypasses the required client cancellation reason', async () => {
    const live = booking();
    const prisma: any = {
      booking: {
        findFirst: vi.fn(async () => {
          const snapshot = { ...live };
          live.status = 'ACCEPTED'; // another request commits after the initial read
          return snapshot;
        }),
        updateMany: vi.fn(async ({ where, data }) => {
          if (!where.status.in.includes(live.status)) return { count: 0 };
          Object.assign(live, data);
          return { count: 1 };
        }),
        findUniqueOrThrow: vi.fn(async () => ({ ...live }))
      },
      $transaction: async (cb: any) => cb(prisma)
    };
    const service = new BookingsService(prisma, new PrismaBookingLocks(prisma), {} as any);
    const result = await service.cancelAsClient(USER, ID, {});
    expect(result.status).toBe('CANCELLED');
    expect(live.cancellationReason).toBeNull();
    expect(prisma.booking.updateMany.mock.calls[0][0].where.status.in).toEqual(['PENDING', 'ACCEPTED']);
  });

  it('a quote cancelled after its initial read still creates a booking', async () => {
    const live = quote();
    const prisma: any = {
      quote: { findFirst: vi.fn(async () => ({ ...live })) },
      venue: { findUniqueOrThrow: vi.fn(async () => {
        live.status = 'CANCELLED'; // cancellation commits while convert is awaiting a read
        return { bookingMode: 'SINGLE_SLOT' };
      }) },
      booking: { create: vi.fn(async () => {
        expect(live.status).toBe('CANCELLED');
        live.booking = { id: 'new-booking' };
        return live.booking;
      }) }
    };
    const service = new QuotesService(new PrismaQuoteStore(prisma), prisma);
    const result = await service.convert(USER, ID, {
      contactFirstName: 'Client', contactLastName: 'Test',
      contactPhone: '0550000000', paymentMethod: 'CASH'
    });
    expect(prisma.booking.create).toHaveBeenCalledTimes(1);
    expect(result.status).toBe('CANCELLED');
    expect(result.bookingId).toBe('new-booking');
  });

  it('notification payload lookup rejects an already committed acceptance', async () => {
    const live = booking();
    const prisma: any = {
      booking: { findFirst: vi.fn(async () => ({ ...live })) },
      venue: { findUniqueOrThrow: vi.fn(async () => ({
        id: VENUE, nameFr: 'Salle', nameAr: 'Salle',
        owner: { phone: '0550000000', notifyByEmail: true, notifyBySms: false,
          user: { id: USER, email: 'test@example.com', locale: 'fr' } }
      })) },
      user: { findUnique: vi.fn(async () => { throw new Error('notification lookup failed'); }) }
    };
    const locks: any = { acceptUnderVenueLock: vi.fn(async () => {
      live.status = 'ACCEPTED';
      return { outcome: 'ACCEPTED', row: { ...live } };
    }) };
    const events: any = { publish: vi.fn(async () => undefined) };
    const service = new BookingsService(prisma, locks, events);
    await expect(service.accept(USER, ID)).rejects.toThrow('notification lookup failed');
    expect(live.status).toBe('ACCEPTED');
    expect(events.publish).not.toHaveBeenCalled();
  });

  it('two simultaneous password resets both consume the same one-use token', async () => {
    const token = { id: ID, userId: USER, usedAt: null as Date | null,
      user: { status: 'ACTIVE' } };
    let reads = 0;
    let release!: () => void;
    const bothRead = new Promise<void>(resolve => { release = resolve; });
    let transactionQueue = Promise.resolve();
    const prisma: any = {
      passwordResetToken: {
        findFirst: vi.fn(async () => {
          const snapshot = { ...token };
          if (++reads === 2) release();
          await bothRead;
          return snapshot;
        }),
        update: vi.fn(async ({ data }) => Object.assign(token, data))
      },
      user: { update: vi.fn(async () => ({})) },
      refreshToken: { updateMany: vi.fn(async () => ({ count: 0 })) },
      $transaction: (cb: any) => {
        const next = transactionQueue.then(() => cb(prisma));
        transactionQueue = next.then(() => undefined);
        return next;
      }
    };
    const service = new AuthService(prisma,
      { hash: async (s: string) => 'hashed-' + s } as any,
      { hash: (s: string) => s } as any, {} as any, {} as any, {} as any,
      { setContext() {}, info() {} } as any, {} as any);
    const results = await Promise.all([
      service.resetPassword('same-token', 'First-password'),
      service.resetPassword('same-token', 'Second-password')
    ]);
    expect(results).toEqual([{ status: 'ok' }, { status: 'ok' }]);
    expect(prisma.passwordResetToken.update).toHaveBeenCalledTimes(2);
    expect(prisma.user.update).toHaveBeenCalledTimes(2);
  });

  it('a JSON null response escapes the Chargily malformed-response boundary', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('null', { status: 200 })));
    const gateway = new ChargilyGateway({ baseUrl: 'https://provider.invalid', secretKey: 'dummy', timeoutMs: 1000 });
    await expect(gateway.createCheckout({ paymentId: ID, amountCents: 18_000_000,
      currency: 'DZD', successUrl: 'https://example.com/success', failureUrl: 'https://example.com/failure'
    })).rejects.toBeInstanceOf(TypeError);
  });
});
