# Zwadj SOLID/Strategy audit evidence

This archive contains NEW audit material only; it does not contain replacement production source or dependencies. Paths for the two diagnostic files are relative to the root of zwadj(5).zip. Logs and measured inventories are under audit-evidence/.

## Diagnostic probes

The seven probes execute real project services, adapters, or pure functions with controlled database/provider doubles. They assert the CURRENT UNWANTED behavior. Their passing result means the defect was reproduced, not that a fix passed. They are not proposed permanent regression tests. Account-deletion approval and the related quote-revision paths were source-level findings, not additional probes.

To repeat the probes, extract the original project, prepare its dependencies and generate its real Prisma client following the project instructions, then add these two files preserving their paths:

- apps/api/audit-probes/architecture.spec.ts
- apps/api/vitest.audit.config.ts

From apps/api, run:

    node node_modules/vitest/vitest.mjs run --config vitest.audit.config.ts

The diagnostic tests mock persistence and fetch. They do not require or simulate every detail of a real PostgreSQL server. Production lock/isolation guarantees need database integration tests after correction. All provider endpoints/identities in the diagnostic fixtures are dummy values.

## Existing checks

The exact underlying commands, workspace directories, and exit codes are recorded in logs/tests-results.json and logs/gates-results.json. Existing suites: 1,310 tests across 107 test files. All passed. Eight workspace TypeScript checks and eight ESLint checks passed. Generated output and dependencies are not included.

Node used: 24.19.0 (project nvmrc: 22). Local package executables were invoked directly because the available pnpm was 11.19.0 and the project pins 10.34.4. A cached dependency tree with an identical lockfile was used after normal installation could not complete. These are evidence for the commands actually run, not a claim that every root-script gate, production build, browser E2E, migration, or mutation campaign succeeded.

## Integrity and inventory

archive-integrity.json records the archive hash and every original file hash. All 541 original files matched after review. source-inventory.json records the AST scan of the 422 original TypeScript/TSX files; its production subset contains 248 modules. Temporary probes and generated files were not counted as original production modules.
