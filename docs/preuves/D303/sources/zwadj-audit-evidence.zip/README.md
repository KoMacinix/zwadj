# Zwadj — preuves des audits, révision du 9 septembre 2026

Ce ZIP contient des résultats d'audit, pas un correctif à déployer.

- `v5/` conserve exactement les entrées de l'archive de preuves initiale (zwadj(5).zip).
- `v6/` contient les mesures portant sur zwadj(6).zip. Les chemins des sondes temporaires sont conservés sous `v6/apps/api/` ; ces fichiers ne sont pas dans l'application auditée.
- Les données de test et identifiants de sondes sont factices. Les accès à la base sont simulés dans les sondes comparatives.

Mesures v6 : 653 tests API / 57 fichiers ; six contrôles TypeScript/ESLint API-types-i18n ; dix sondes supplémentaires ; sept mutations du nouveau calcul qui font réellement échouer des assertions, puis 13 tests verts après restauration.
Le run de sondes a également collecté la suite API : 663 tests / 58 fichiers = 653 + 10, pas 663 nouveaux tests.

Les JSON Vitest portent à la fois des nombres de blocs describe et les fichiers : pour compter les fichiers, lire `testResults.length`. Les erreurs attendues dans les logs des tests ne signifient pas que la suite a échoué ; consulter `success`, `numFailedTests` et le code de sortie.

`harness-calibration.log` est une simulation des sorties de processus montrant un faux succès possible du harnais, et non une exécution Vitest réelle. Les mutations réellement exécutées sont dans `mutation-results.json` et les sorties `mutation-*.json/.log`. La cible 8 nécessitant PostgreSQL reste non exécutée ici (code 3 du harnais complet).

`dependency-advisories-snapshot.json` conserve les 55 entrées factuelles, les 53 GHSA, les versions et chemins affectés du résultat consulté, sans recopier les descriptions intégrales des avis. Les 11 signalements supplémentaires par rapport à l'ancien audit ne correspondent à aucune modification du lockfile.

Les rapports distinguent les vérifications indépendantes des résultats PostgreSQL/E2E/build annoncés par l'auteur dans D279. Aucun PostgreSQL, Docker, déploiement ou prestataire de paiement n'a été utilisé pour cette révision.

Pour rejouer les dix sondes : disposer des deux archives extraites comme dossiers voisins `zwadj-audit` et `zwadj-audit-v6`, préparer leurs dépendances et générer leurs vrais clients Prisma, puis copier les deux fichiers de `v6/apps/api/` dans l'API v6. Depuis cette API :

    node node_modules/vitest/vitest.mjs run -c vitest.review.config.ts review-probes/charge-wiring.spec.ts

Pour la campagne fournie par le projet, depuis la racine v6 :

    python3 neutralisation/neutralize-s11b.py

Sans base réelle, la cible d'intégration est signalée non mesurée. Dans notre environnement, le lanceur pnpm a été remplacé en mémoire par l'exécutable Vitest local ; les JSON de chaque passage ont été vérifiés pour distinguer assertion échouée et panne d'infrastructure. Le code original a été restauré et comparé au ZIP.
